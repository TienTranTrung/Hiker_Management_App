﻿using M_Hike_Hybrid_App.Persistence;
using M_Hike_Hybrid_App.ViewModels;
using Xamarin.Forms;

namespace M_Hike_Hybrid_App.Views
{
    public partial class HikesPage : ContentPage
    {
        public HikesPage()
        {
            var hikeStore = new SQLiteHikeStore(DependencyService.Get<ISQLiteDb>());
            var pageService = new PageService();

            ViewModel = new HikesPageViewModel(hikeStore, pageService);

            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            ViewModel.LoadDataCommand.Execute(null);
            base.OnAppearing();
        }

        void OnHikeSelected(object sender, SelectedItemChangedEventArgs e)
        {
            ViewModel.SelectHikeCommand.Execute(e.SelectedItem);
        }

        public HikesPageViewModel ViewModel
        {
            get { return BindingContext as HikesPageViewModel; }
            set { BindingContext = value; }
        }
    }
}
