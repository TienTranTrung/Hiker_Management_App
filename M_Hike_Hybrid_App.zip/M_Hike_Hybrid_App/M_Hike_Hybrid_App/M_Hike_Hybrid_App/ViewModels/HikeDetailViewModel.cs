﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using M_Hike_Hybrid_App.Models;
using Xamarin.Forms;

namespace M_Hike_Hybrid_App.ViewModels
{
    public class HikeDetailViewModel
    {
        private readonly IHikeStore _HikeStore;
        private readonly IPageService _pageService;

        public Hike Hike { get; private set; }

        public ICommand SaveCommand { get; private set; }

        public HikeDetailViewModel(HikeViewModel viewModel, IHikeStore HikeStore, IPageService pageService)
        {
            if (viewModel == null)
                throw new ArgumentNullException(nameof(viewModel));

            _pageService = pageService;
            _HikeStore = HikeStore;

            SaveCommand = new Command(async () => await Save());

            Hike = new Hike
            {
                Id = viewModel.Id, 
                Name = viewModel.Name,
                Location = viewModel.Location,
                Date = viewModel.Date,
                ParkingAvailable = viewModel.ParkingAvailable,
                Length = viewModel.Length,
                Difficulty = viewModel.Difficulty,
                Description = viewModel.Description,
                WeatherCondition = viewModel.WeatherCondition,
                EstimatedTime = viewModel.EstimatedTime,
            };
        }

        async Task Save()
        {
            if (String.IsNullOrWhiteSpace(Hike.Name) ||
                    String.IsNullOrWhiteSpace(Hike.Location) ||
                    Hike.Date == null ||
                    String.IsNullOrWhiteSpace(Hike.Length.ToString()) ||
                    String.IsNullOrWhiteSpace(Hike.Difficulty) ||
                    String.IsNullOrWhiteSpace(Hike.EstimatedTime) ||
                    String.IsNullOrWhiteSpace(Hike.WeatherCondition))
            {
                await _pageService.DisplayAlert("Error", "Please fill all required fields.", "OK");
                return;
            }
            if (Hike.Id == 0)
            {
                await _HikeStore.AddHike(Hike);
                MessagingCenter.Send(this, Events.HikeAdded, Hike);
            }
            else
            {
                await _HikeStore.UpdateHike(Hike);
                MessagingCenter.Send(this, Events.HikeUpdated, Hike);
            }
            await _pageService.PopAsync();
        }
    }
}
