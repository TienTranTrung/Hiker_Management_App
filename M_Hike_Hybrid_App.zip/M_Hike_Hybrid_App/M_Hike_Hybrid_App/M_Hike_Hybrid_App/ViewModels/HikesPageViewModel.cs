﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using M_Hike_Hybrid_App.Models;
using M_Hike_Hybrid_App.ViewModels;
using M_Hike_Hybrid_App.Views;
using Xamarin.Forms;

namespace M_Hike_Hybrid_App.ViewModels
{
    public class HikesPageViewModel : BaseViewModel
    {
        private HikeViewModel _selectedHike;
        private IHikeStore _hikeStore;
        private IPageService _pageService;

        private bool _isDataLoaded;

        public ObservableCollection<HikeViewModel> Hikes { get; private set; }
            = new ObservableCollection<HikeViewModel>();

        public HikeViewModel SelectedHike
        {
            get { return _selectedHike; }
            set { SetValue(ref _selectedHike, value); }
        }

        public ICommand LoadDataCommand { get; private set; }
        public ICommand AddHikeCommand { get; private set; }
        public ICommand SelectHikeCommand { get; private set; }
        public ICommand DeleteHikeCommand { get; private set; }
        public ICommand ResetDatabaseCommand { get; private set; }

        public HikesPageViewModel(IHikeStore hikeStore, IPageService pageService)
        {
            _hikeStore = hikeStore;
            _pageService = pageService;

            LoadDataCommand = new Command(async () => await LoadData());
            AddHikeCommand = new Command(async () => await AddHike());
            SelectHikeCommand = new Command<HikeViewModel>(async c => await SelectHike(c));
            DeleteHikeCommand = new Command<HikeViewModel>(async c => await DeleteHike(c));
            ResetDatabaseCommand = new Command(async () => await ResetDatabase());

            MessagingCenter.Subscribe<HikeDetailViewModel, Hike>
                (this, Events.HikeAdded, OnHikeAdded);

            MessagingCenter.Subscribe<HikeDetailViewModel, Hike>
            (this, Events.HikeUpdated, OnHikeUpdated);
        }

        private void OnHikeAdded(HikeDetailViewModel source, Hike hike)
        {
            Hikes.Add(new HikeViewModel(hike));
        }

        private void OnHikeUpdated(HikeDetailViewModel source, Hike hike)
        {
            var hikeInList = Hikes.Single(c => c.Id == hike.Id);

            hikeInList.Id = hike.Id;
            hikeInList.Name = hike.Name;
            hikeInList.Location = hike.Location;
            hikeInList.Date = hike.Date;
            hikeInList.ParkingAvailable = hike.ParkingAvailable;
            hikeInList.Length = hike.Length;
            hikeInList.Difficulty = hike.Difficulty;
            hikeInList.Description = hike.Description;
            hikeInList.EstimatedTime = hike.EstimatedTime;
            hikeInList.WeatherCondition = hike.WeatherCondition;
        }

        private async Task LoadData()
        {
            if (_isDataLoaded)
                return;

            _isDataLoaded = true;
            var hikes = await _hikeStore.GetHikesAsync();
            foreach (var hike in hikes)
                Hikes.Add(new HikeViewModel(hike));
        }

        private async Task AddHike()
        {
            var newHike = new HikeViewModel
            {
                // Initialize with default values or leave properties as null depending on your requirements
            };
            await _pageService.PushAsync(new HikeDetailPage(newHike));
        }

        private async Task SelectHike(HikeViewModel hike)
        {
            if (hike == null)
                return;

            SelectedHike = null;
            await _pageService.PushAsync(new HikeDetailPage(hike));
        }

        private async Task DeleteHike(HikeViewModel hikeViewModel)
        {
            if (await _pageService.DisplayAlert("Warning", $"Are you sure you want to delete {hikeViewModel.Name}?", "Yes", "No"))
            {
                Hikes.Remove(hikeViewModel);

                var hike = await _hikeStore.GetHike(hikeViewModel.Id);
                await _hikeStore.DeleteHike(hike);
            }
        }
        private async Task ResetDatabase()
        {
            var confirm = await _pageService.DisplayAlert("Confirmation", "Are you sure you want to reset the database?", "Yes", "No");
            if (confirm)
            {
                await _hikeStore.ClearDatabase();
                // Refresh the hikes list
                await LoadData();
                OnPropertyChanged(nameof(Hikes));
            }
        }
    }
}
