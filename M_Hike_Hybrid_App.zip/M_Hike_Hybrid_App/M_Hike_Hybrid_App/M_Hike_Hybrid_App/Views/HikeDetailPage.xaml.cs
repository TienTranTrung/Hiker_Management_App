﻿using M_Hike_Hybrid_App.Persistence;
using M_Hike_Hybrid_App.ViewModels;
using Xamarin.Forms;

namespace M_Hike_Hybrid_App.Views
{
    public partial class HikeDetailPage : ContentPage
    {
        public HikeDetailPage(HikeViewModel viewModel)
        {
            InitializeComponent();

            var hikeStore = new SQLiteHikeStore(DependencyService.Get<ISQLiteDb>());
            var pageService = new PageService();
            Title = (viewModel.Name == null) ? "New Hike" : "Edit Hike";
            BindingContext = new HikeDetailViewModel(viewModel ?? new HikeViewModel(), hikeStore, pageService);
        }
    }
}