﻿using System;
using System.Collections.Generic;
using System.Text;

namespace M_Hike_Hybrid_App.Models
{
    internal class Observation
    {
    }
}
