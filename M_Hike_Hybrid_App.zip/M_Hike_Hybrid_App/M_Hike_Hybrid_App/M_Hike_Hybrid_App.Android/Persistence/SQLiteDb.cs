﻿using System;
using System.IO;
using SQLite;
using M_Hike_Hybrid_App.Persistence;
using Xamarin.Forms;
using M_Hike_Hybrid_App.Droid;

[assembly: Dependency(typeof(SQLiteDb))]

namespace M_Hike_Hybrid_App.Droid
{
    public class SQLiteDb : ISQLiteDb
    {
        public SQLiteAsyncConnection GetConnection()
        {
            var documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            var path = Path.Combine(documentsPath, "MySQLite.db3");

            return new SQLiteAsyncConnection(path);
        }
    }
}
