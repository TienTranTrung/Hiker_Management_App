﻿using System;
namespace M_Hike_Hybrid_App.ViewModels
{
    public static class Events
    {
        public static string HikeAdded = "AddHike";
        public static string HikeUpdated = "UpdateHike";
    }
}
