﻿using SQLite;

namespace M_Hike_Hybrid_App.Persistence
{
    public interface ISQLiteDb
    {
        SQLiteAsyncConnection GetConnection();
    }
}
