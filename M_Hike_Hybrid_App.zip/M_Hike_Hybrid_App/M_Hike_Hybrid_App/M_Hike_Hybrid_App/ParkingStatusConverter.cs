﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace M_Hike_Hybrid_App.Converters
{
    public class BooleanToAvailabilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool booleanValue)
            {
                return booleanValue ? "Available" : "Unavailable";
            }
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string stringValue)
            {
                return stringValue == "Available";
            }
            return value;
        }
    }
}