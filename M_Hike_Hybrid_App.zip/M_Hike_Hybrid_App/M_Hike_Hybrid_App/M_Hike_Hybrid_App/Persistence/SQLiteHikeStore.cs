﻿using System.Collections.Generic;
using System.Threading.Tasks;
using M_Hike_Hybrid_App.Models;
using M_Hike_Hybrid_App.Persistence;
using M_Hike_Hybrid_App.ViewModels;
using SQLite;

namespace M_Hike_Hybrid_App
{
    public class SQLiteHikeStore : IHikeStore
    {
        private SQLiteAsyncConnection _connection;

        public SQLiteHikeStore(ISQLiteDb db)
        {
            _connection = db.GetConnection();
            _connection.CreateTableAsync<Hike>();
        }

        public async Task<IEnumerable<Hike>> GetHikesAsync()
        {
            return await _connection.Table<Hike>().ToListAsync();
        }

        public async Task DeleteHike(Hike hike)
        {
            await _connection.DeleteAsync(hike);
        }

        public async Task AddHike(Hike hike)
        {
            await _connection.InsertAsync(hike);
        }

        public async Task UpdateHike(Hike hike)
        {
            await _connection.UpdateAsync(hike);
        }

        public async Task<Hike> GetHike(int id)
        {
            return await _connection.FindAsync<Hike>(id);
        }
        public async Task ClearDatabase()
        {
            await _connection.DropTableAsync<Hike>();
            await _connection.CreateTableAsync<Hike>();
        }
    }
}
