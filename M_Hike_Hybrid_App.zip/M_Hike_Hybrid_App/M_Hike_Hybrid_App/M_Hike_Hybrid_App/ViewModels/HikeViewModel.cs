﻿using M_Hike_Hybrid_App.Models;
using System;

using Xamarin.Forms;

namespace M_Hike_Hybrid_App.ViewModels
{
    public class HikeViewModel : BaseViewModel
    {
        public int Id { get; set; }

        public HikeViewModel() { }

        public HikeViewModel(Hike hike)
        {
            Id = hike.Id;
            Name = hike.Name;
            Location = hike.Location;
            Date = hike.Date;
            ParkingAvailable = hike.ParkingAvailable;
            Length = hike.Length;
            Difficulty = hike.Difficulty;
            Description = hike.Description;
            WeatherCondition = hike.WeatherCondition;
            EstimatedTime = hike.EstimatedTime;
        }

        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                SetValue(ref _name, value);
            }
        }

        private string _location;
        public string Location
        {
            get { return _location; }
            set
            {
                SetValue(ref _location, value);
            }
        }

        private DateTime _date;
        public DateTime Date
        {
            get { return _date; }
            set
            {
                SetValue(ref _date, value);
            }
        }

        private bool _parkingAvailable;
        public bool ParkingAvailable
        {
            get { return _parkingAvailable; }
            set
            {
                SetValue(ref _parkingAvailable, value);
            }
        }

        private double _length;
        public double Length
        {
            get { return _length; }
            set
            {
                SetValue(ref _length, value);
            }
        }

        private string _difficulty;
        public string Difficulty
        {
            get { return _difficulty; }
            set
            {
                SetValue(ref _difficulty, value);
            }
        }

        private string _description;
        public string Description
        {
            get { return _description; }
            set
            {
                SetValue(ref _description, value);
            }
        }
        private string _estimatedTime;
        public string EstimatedTime
        {
            get { return _estimatedTime; }
            set
            {
                SetValue(ref _estimatedTime, value);
            }
        }

        private string _weatherCondition;
        public string WeatherCondition
        {
            get { return _weatherCondition; }
            set
            {
                SetValue(ref _weatherCondition, value);
            }
        }
        public ImageSource HikeImage
        {
            get
            {
                if (ParkingAvailable)
                {
                    return ImageSource.FromUri(new Uri("https://images.unsplash.com/reserve/91JuTaUSKaMh2yjB1C4A_IMG_9284.jpg?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"));
                }
                return ImageSource.FromUri(new Uri("https://images.unsplash.com/photo-1520962880247-cfaf541c8724?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1932&q=80"));
            }
        }
    }
}
