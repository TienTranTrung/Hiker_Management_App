﻿using System.Collections.Generic;
using System.Threading.Tasks;
using M_Hike_Hybrid_App.Models;

namespace M_Hike_Hybrid_App.ViewModels
{
    public interface IHikeStore
    {
        Task<IEnumerable<Hike>> GetHikesAsync();

        Task<Hike> GetHike(int id);

        Task AddHike(Hike hike);

        Task UpdateHike(Hike hike);

        Task DeleteHike(Hike hike);
        Task ClearDatabase();

    }
}